let miNumero:number = 10;

miNumero = 10+10;
miNumero = miNumero + 10;

console.log(miNumero); // 30

let booleano : boolean = true;
booleano = false;
booleano = !booleano;

let encendido : boolean = true;
console.log(encendido); // true