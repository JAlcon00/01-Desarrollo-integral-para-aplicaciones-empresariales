let mensaje:string = 'Hola Mundo';

console.log(mensaje);

let numero:number = 10;
numero = 10.50;
console.log(numero);