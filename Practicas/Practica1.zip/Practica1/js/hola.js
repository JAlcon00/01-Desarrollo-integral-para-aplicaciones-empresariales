var mensaje = 'Hola Mundo';
console.log(mensaje);
var numero = 10;
numero = 10.50;
console.log(numero);
